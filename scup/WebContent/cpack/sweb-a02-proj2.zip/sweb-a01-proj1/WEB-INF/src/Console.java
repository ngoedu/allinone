/**
 * Milestone 3
 * @author Administrator
 *
 */
public class Console {
	public static void main(String args[]) {
		String dt = new java.util.Date().toGMTString();
		System.out.println(dt);
		System.out.println(new java.util.Date() + ",MS-3");
	}
}

