/**
 *MileStone2
 */

function add(a, b) {
	return a+b;
}

function ad2d(a, b) {
	return a+b;
}

alert("ms-3");
